﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

using capaDatos;

namespace capaNegocio
{
    [Serializable]
    public class Inmobiliaria
    {
        private string nom;
        private List<Usuario> listausuarios;
        private List<Cliente> listaclientes;
        private List<Vendedor> listavendedor;
        private List<Dpto> listadptos;
        private List<Casa> listacasas;
        private List<Sucursal> listasucursal;
        private List<Venta> listaventas;
        private List<Reserva> listareserva;
        private List<Comision> listacomision;
        private List<Alquiler> listaalquiler;

        public Inmobiliaria(string n)
        {
            nom = n;
            listausuarios = new List<Usuario>();
            listaclientes = new List<Cliente>();
            listavendedor = new List<Vendedor>();
            listadptos = new List<Dpto>();
            listacasas = new List<Casa>();
            listasucursal = new List<Sucursal>();
            listaventas = new List<Venta>();
            listareserva = new List<Reserva>();
            listacomision = new List<Comision>();
            listaalquiler = new List<Alquiler>();
        }
        //--------------Usuario----------------
        public List<Usuario> ListaUsuarios
        {
            get { return listausuarios; }
        }
        public void AgregarUsuario(Usuario u)
        {
            listausuarios.Add(u);
        }
        public void EliminarUsuario(Usuario u)
        {
            listausuarios.Remove(u);            
        }
        //--------------Cliente----------------
        public List<Cliente> ListaClientes
        {
            get { return listaclientes; }
        }
        public void AgregarCliente(Cliente c)
        {
            listaclientes.Add(c);
        }
        public void EliminarCliente(Cliente c)
        {
            listaclientes.Remove(c);
        }
        public int CantCli()
        {
            return listaclientes.Count;
        }
        //--------------Vendedor----------------
        public List<Vendedor> ListaVendedor
        {
            get { return listavendedor; }
        }
        public void AgregarVendedor(Vendedor v)
        {
            listavendedor.Add(v);
        }
        public void EliminarVendedor(Vendedor v)
        {
            listavendedor.Remove(v);
        }
        public int CantVen()
        {
            return listavendedor.Count;
        }
        //-----------------Casa-----------------
        public void agregarCasa(Casa c)
        {
            listacasas.Add(c);
        }
        public void eliminarCasa(Casa c)
        {
            listacasas.Remove(c);
        }
        public List<Casa> Casas
        {
            get { return listacasas; }
        }
        public int CantCasa()
        {
            return listacasas.Count;
        }
        //--------------Departamento------------
        public void agregarDpto(Dpto d)
        {
            listadptos.Add(d);
        }
        public void eliminarDpto(Dpto d)
        {
            listadptos.Remove(d);
        }
        public List<Dpto> Dptos
        {
            get { return listadptos; }
        }
        public int CantDpto()
        {
            return listadptos.Count;
        }
        //----------------Sucursal--------------
        public List<Sucursal> ListaSucural
        {
            get { return listasucursal; }
        }
        public void AgregarSucursal(Sucursal s)
        {
            listasucursal.Add(s);
        }

        public void EliminarSucursal(Sucursal s)
        {
            listasucursal.Remove(s);
        }
        public int CantSucursal()
        {
            return listasucursal.Count;
        }
        //-----------------Ventas---------------
        public List<Venta> ListaVentas
        {
            get { return listaventas; }
        }
        public void AgregarUnaVenta(Venta v)
        {
            listaventas.Add(v);
        }
        public void EliminarUnaVenta(Venta v)
        {
            listaventas.Remove(v);
        }
        public int CantVentas()
        {
            return listaventas.Count;
        }
        //-----------------Alquiler---------------
        public List<Alquiler> ListaAlquiler
        {
            get { return listaalquiler; }
        }
        public void AgregarUnAlquiler(Alquiler a)
        {
            listaalquiler.Add(a);
        }
        public void EliminarUnAlquilera(Venta v)
        {
            listaventas.Remove(v);
        }
        public int CantAlquileres()
        {
            return listaventas.Count;
        }
        //-----------------Reserva---------------
        public List<Reserva> Reserva
        {
            get { return listareserva; }
        }
        public void AgregarReserva(Reserva u)
        {
            listareserva.Add(u);
        }
        public void EliminarReserva(Reserva u)
        {
            listareserva.Remove(u);
        }
        //-----------------Comision---------------
        public List<Comision> ListaComisiones
        {
            get { return listacomision; }
        }
        public void AgregarComision(Comision m)
        {
            listacomision.Add(m);
        }
        public void EliminarComision(Comision m)
        {
            listacomision.Remove(m);
        }
        public int CantComision()
        {
            return listacomision.Count;
        }
        //--------------Serializado-------------

        public static Inmobiliaria Recuperar(string file)
        {
            Inmobiliaria i = (Inmobiliaria)Serializar.Recuperar(file);
            if (i == null)
                i = new Inmobiliaria("AMBA Propiedades");
            return i;
        }
        public bool guardarCliente()
        {
            return Serializar.Guardar(this, "Cliente.dat");
        }
        public bool guardarVendedor()
        {
            return Serializar.Guardar(this, "Vendedor.dat");
        }
        public bool guardarCasa()
        {
            return Serializar.Guardar(this, "Casa.dat");
        }
        public bool guardarCasaVendida()
        {
            return Serializar.Guardar(this, "CasaVendida.dat");
        }
        public bool guardarDepartamento()
        {
            return Serializar.Guardar(this, "Departamento.dat");
        }
        public bool guardarSucursal()
        {
            return Serializar.Guardar(this, "Sucursal.dat");
        }
        public bool guardarVenta()
        {
            return Serializar.Guardar(this, "Venta.dat");
        }
        public bool guardarReserva()
        {
            return Serializar.Guardar(this, "Reserva.dat");
        }
        public bool guardarComision()
        {
            return Serializar.Guardar(this, "Comision.dat");
        }
        public bool guardarAlquiler()
        {
            return Serializar.Guardar(this, "Alquiler.dat");
        }
    }
}
