﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capaNegocio
{
    [Serializable]
    public class Alquiler
    {
        protected DateTime fventa;
        protected string idCliente;
        protected string idInmueble;
        protected int idLegajo;
        protected int idSucursal;
        protected double costo;

        public Alquiler(string idc, string idin, int idleg, int idsuc,
                    double c)
        {
            idCliente = idc;
            idInmueble = idin;
            idLegajo = idleg;
            idSucursal = idsuc;
            costo = c;
            fventa = DateTime.Today;
        }
        public String IdCliente
        {
            set { idCliente = value; }
            get { return this.idCliente; }
        }
        public String IdInmueble
        {
            set { idInmueble = value; }
            get { return this.idInmueble; }
        }
        public int IdLegajo
        {
            set { idLegajo = value; }
            get { return this.idLegajo; }
        }
        public int IdSucursal
        {
            set { idSucursal = value; }
            get { return this.idSucursal; }
        }
        public DateTime FVenta
        {
            get { return fventa; }
            set { this.fventa = value; }
        }
        public double CostoVenta        
        {
            set { costo = value; }
            get { return this.costo; }
        }
        public override string ToString()
        {
            return IdInmueble + " - " + idCliente + " - " + idLegajo;
        }

    }
}
