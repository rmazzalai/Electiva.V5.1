﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capaNegocio
{
    [Serializable]
    public class Comision
    {
        protected DateTime fcomision;
        protected Cliente idCliente;
        protected Casa idCasa;
        protected Dpto idDpto;
        protected Vendedor idLegajo;
        protected Sucursal idSucursal;
        protected string concepto;
        protected double comision;

        public Comision(Cliente idl, Casa idc, Dpto idd, Vendedor idleg, Sucursal idsuc, 
                    double c, string cpto)
        {
            this.idCliente = idl;
            this.idCasa = idc;
            this.idDpto = idd;
            this.idLegajo = idleg;
            this.idSucursal = idsuc;
            this.comision = c;
            this.fcomision = DateTime.Today;
            this.concepto = cpto;
        }
        public Cliente IdCliente
        {
            set { idCliente = value; }
            get { return idCliente; }
        }
        public Casa IDCasa
        {
            set { idCasa = value; }
            get { return this.idCasa; }
        }
        public Dpto IDDpto
        {
            set { idDpto = value; }
            get { return this.idDpto; }
        }
        public Vendedor IdLegajo
        {
            set { idLegajo = value; }
            get { return this.idLegajo; }
        }
        public Sucursal IdSucursal
        {
            set { idSucursal = value; }
            get { return this.idSucursal; }
        }
        public DateTime FComision
        {
            get { return fcomision; }
            set { this.fcomision = value; }
        }
        public string Concepto
        {
            set { concepto = value; }
            get { return this.concepto; }
        }
        public double ComisionVenta
        {
            set { comision = value; }
            get { return this.comision; }
        }
        public override string ToString()
        {
            var vivienda = " ";

            if (idCasa != null)
            {
                vivienda = idCasa.Id + " DIRECCION: " + idCasa.Calle + " " + idCasa.Nro + ", " + idCasa.Localidad + ", " + idCasa.Provincia;
            }
            else
                if (idDpto != null)
            {
                vivienda = idDpto.Id + " DIRECCION: " + idDpto.Calle + " " + idDpto.Nro + " PISO:" + idDpto.NroPiso + " DPTO: " + idDpto.NroDpto + ", " + idDpto.Localidad + ", " + idDpto.Provincia;
            }

            return $" = {fcomision.ToString("dd/MM/yyyy")} {Concepto} {IdCliente.Apellido} {idCliente.Nombre} {idSucursal.Localidad} {vivienda}";
        }
    }
}
