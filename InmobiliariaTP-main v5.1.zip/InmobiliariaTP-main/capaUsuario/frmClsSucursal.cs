﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsSucursal : Form
    {
        Inmobiliaria isuc = new Inmobiliaria("inmo");
        private Sucursal suc;
        private int cant;

        public frmClsSucursal(Sucursal s, bool b, int cansuc)
        {
            InitializeComponent();
            if (b)
            {
                btnIngresar.Enabled = true;
            }
            else
            {
                btnActualizar.Enabled = true;
                txtIdPartido.Enabled = false;
            }
            if (s != null)
                CargarSucursal(s);
                suc = s;
            cant = cansuc++ + 10;
        }
        public Sucursal Suc
        {
            get { return suc; }
        }
        private void frmClsSucursal_Load(object sender, EventArgs e)
        {
            txtIdPartido.Enabled = false;
            txtIdPartido.Text = cant.ToString();
        }
        private void btnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                string pa = cmbPartido.Text;
                string loc = cmbLocalidad.Text;
                string pro = cmbProvincia.Text;              
                int id = int.Parse(txtIdPartido.Text);
                double valor = double.Parse(txtvalor.Text);               
                suc = new Sucursal(pa, loc, pro, id, valor);
                                
                isuc.AgregarSucursal(suc);

                CargarCompViewS();

                MessageBox.Show("Se ingreso correctamente la Sucursal:" + id);

                Limpiar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            suc.Partido = cmbPartido.Text;
            suc.Localidad = cmbLocalidad.Text;
            suc.Provincia = cmbProvincia.Text;
            suc.Preciom2 = double.Parse(txtvalor.Text);
            suc.IdSucursal = int.Parse(txtIdPartido.Text);
        }
        private void CargarSucursal(Sucursal s)
        {
            try
            {
                cmbPartido.Text = s.Partido;
                cmbLocalidad.Text = s.Localidad;
                cmbProvincia.Text = s.Provincia;
                txtvalor.Text = s.Preciom2.ToString();                           
                txtIdPartido.Text = s.IdSucursal.ToString();

                CargarCompViewS();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            btnLimpiar.Enabled = false;
        }
        private void CargarCompViewS()
        {
            //Cargar DataGridView.
            dtgViewTabla.DataSource = null;
            dtgViewTabla.DataSource = isuc.ListaSucural;
            dtgViewTabla.ClearSelection();

            this.cmbPartido.Focus();
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }
        private void Limpiar()
        {
            cmbPartido.Text = "";
            cmbLocalidad.Text = "";
            cmbProvincia.Text = "Bs.As.";
            txtvalor.Text = "";
            txtIdPartido.Text = "0";
            
            this.cmbPartido.Focus();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
