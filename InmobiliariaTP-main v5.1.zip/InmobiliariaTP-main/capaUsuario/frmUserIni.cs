﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmUserIni : Form
    {
        private Inmobiliaria icli;
        private Inmobiliaria iven;
        private int cantcli;
        private int cantven;
       
        public frmUserIni()
        {
            icli = Inmobiliaria.Recuperar("Cliente.dat");
            iven = Inmobiliaria.Recuperar("Vendedor.dat");

            InitializeComponent();
            //Cargar List y DataView.
            CargarCompView();
            CargarCompViewV();

            cantcli = icli.CantCli();
            cantven = iven.CantVen();
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {            
            Cliente c = null;            
            frmClsCliente agregar = new frmClsCliente(c, true, cantcli);
            CargarInfo(agregar);
        }
        private void CargarInfo(frmClsCliente agregar) 
        {
            agregar.ShowDialog();            
            Cliente cli = agregar.Cli;
            if (cli != null)
            {                
                icli.AgregarCliente(cli);

                //Almacenar info. Cliente.
                GuardarCliente();

                //Cargar List y DataView.
                CargarCompView();
            }
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {            
            Cliente c = (Cliente)lstTablaC.SelectedItem;
            if (c != null)
            {
                frmClsCliente agregar = new frmClsCliente(c, false, cantcli);
                agregar.ShowDialog();

                //Almacenar info. Cliente.
                GuardarCliente();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono un Cliente.");
        }
        private void btnEliminarC_Click(object sender, EventArgs e)
        {
            Cliente c = (Cliente)lstTablaC.SelectedItem;
            if (c != null)
            {
                icli.EliminarCliente(c);

                //Almacenar info. Cliente.
                GuardarCliente();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono un Cliente.");
        }
        //--------------------Vendedor-------------------
        private void btnVendedor_Click_1(object sender, EventArgs e)
        {
            Vendedor v = null;
            frmClsVendedor agregar = new frmClsVendedor(v, true, cantven);
            CargarInfo(agregar);
        }
        private void CargarInfo(frmClsVendedor agregar)
        {
            agregar.ShowDialog();
            Vendedor ven = agregar.Ven;
            if (ven != null)
            {
                //Cargar el ListBox
                iven.AgregarVendedor(ven);

                //Almacenar info. Vendedor.
                GuardarVendedor();

                //Cargar List y DataView.
                CargarCompViewV();
            }
        }
        private void btnActualizarV_Click(object sender, EventArgs e)
        {
            Vendedor v = (Vendedor)lstTablaV.SelectedItem;
            if (v != null)
            {
                frmClsVendedor agregar = new frmClsVendedor(v, false, cantven);
                agregar.ShowDialog();

                //Almacenar info. Vendedor.
                GuardarVendedor();

                //Cargar List y DataView.
                CargarCompViewV();
            }
            else
                MessageBox.Show("No selecciono un Vendedor.");
        }
        private void btnEliminarV_Click(object sender, EventArgs e)
        {
            Vendedor v = (Vendedor)lstTablaV.SelectedItem;
            if (v != null)
            {
                iven.EliminarVendedor(v);

                //Almacenar info. Vendedor.
                GuardarVendedor();

                //Cargar List y DataView.
                CargarCompViewV();
            }
            else
                MessageBox.Show("No selecciono un Vendedor.");
        }
        //--------------------DataGridView-------------------
        private void Encabezado()
        {
            try
            {
                dtgViewTablaC.Columns.Add("nombre", "Nombre");
                dtgViewTablaC.Columns.Add("apellido", "Apellido");
                dtgViewTablaC.Columns.Add("dni", "Dni");
                dtgViewTablaC.Columns.Add("calle", "Calle");
                dtgViewTablaC.Columns.Add("altura", "Altura");
                dtgViewTablaC.Columns.Add("localidad", "Localidad");
                dtgViewTablaC.Columns.Add("partido", "Partido");
                dtgViewTablaC.Columns.Add("idcliente", "IdCliente");

                dtgViewTablaV.Columns.Add("nombre", "Nombre");
                dtgViewTablaV.Columns.Add("apellido", "Apellido");
                dtgViewTablaV.Columns.Add("dni", "Dni");
                dtgViewTablaV.Columns.Add("calle", "Calle");
                dtgViewTablaV.Columns.Add("altura", "Altura");
                dtgViewTablaV.Columns.Add("localidad", "Localidad");
                dtgViewTablaV.Columns.Add("partido", "Partido");
                dtgViewTablaV.Columns.Add("legajo", "Legajo");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //--------------------DataGridView-----------------
        private void CargarCompView()
        {
            //Cargar ListBox.
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = icli.ListaClientes; 
            lstTablaC.ClearSelected();

            //Cargar DataGridView.
            dtgViewTablaC.DataSource = null;
            dtgViewTablaC.DataSource = icli.ListaClientes; 
            dtgViewTablaC.ClearSelection();
        }
        private void CargarCompViewV()
        {
            //Cargar ListBox.
            lstTablaV.DataSource = null;
            lstTablaV.DataSource = iven.ListaVendedor; 
            lstTablaV.ClearSelected();

            //Cargar DataGridView.
            dtgViewTablaV.DataSource = null;
            dtgViewTablaV.DataSource = iven.ListaVendedor;
            dtgViewTablaV.ClearSelection();
        }
        //--------------------Serializar-----------------
        private void GuardarCliente()
        {
            if (icli.guardarCliente() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarVendedor()
        {
            if (iven.guardarVendedor() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
