﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsCasa : Form
    {
        private Casa casa;
        private int cant;

        public frmClsCasa(Casa c, bool b, int cantcasa)
        {
            InitializeComponent();
            if (b)
            {
                butActualizarCasa.Enabled = true;
                botAgregar.Enabled = false;
                botAgregar.Visible = false;
            }
            else
            {
                butActualizarCasa.Enabled = false;
                butActualizarCasa.Visible = false;
                botAgregar.Enabled = true;
            }
            if (c != null)
                cargarCasa(c);
            if (c == null)
            {
                casa = c;
                cant = cantcasa + 1;
                txtId.Enabled = false;
                txtId.Text = "CA-" + cant;
            }            
        }
        public Casa Cas
        {
            get { return this.casa; }
        }
        private void cargarCasa(Casa c)
        {
           try
           {
                this.textBoxCalle.Text = c.Calle;
                this.textBoxNumero.Text = c.Nro.ToString() ;
                this.textBoxLocalidad.Text = c.Localidad;
                this.textBoxPartido.Text = c.Partido;
                this.textBoxProvincia.Text = c.Provincia;
                this.textBoxTotalM2.Text = c.M2Terreno.ToString();
                this.textBoxM2Cubiertos.Text = c.M2Cubiertos.ToString();
                this.txtId.Text = c.Id;                
           }
           catch (Exception ex)
           {
                MessageBox.Show(ex.ToString());
           }
        }
        private void botAgregar_Click(object sender, EventArgs e)
        {
            string calle = this.textBoxCalle.Text;
            int nro = int.Parse(this.textBoxNumero.Text);
            string localidad = this.textBoxLocalidad.Text;
            string partido = this.textBoxPartido.Text;
            string provincia = this.textBoxProvincia.Text;
            int m2 = int.Parse(this.textBoxTotalM2.Text);
            int m2Cu = int.Parse(this.textBoxM2Cubiertos.Text);
            string id = this.txtId.Text;
            

            casa = new Casa(calle, nro, localidad, partido, provincia, m2Cu, m2, id);

            this.Close();
        }
        private void butActualizarCasa_Click(object sender, EventArgs e)
        {
            casa.Calle = this.textBoxCalle.Text;
            casa.Nro = int.Parse(this.textBoxNumero.Text);
            casa.Localidad = this.textBoxLocalidad.Text;
            casa.Partido = this.textBoxPartido.Text;
            casa.Provincia = this.textBoxProvincia.Text;
            casa.M2Terreno = int.Parse(this.textBoxTotalM2.Text);
            casa.M2Cubiertos = int.Parse(this.textBoxM2Cubiertos.Text);
            casa.Id = this.txtId.Text;
            
            
            this.Close();
        }
        private void butCancelar_Click(object sender, EventArgs e)
        {
            casa = null;
            this.Close();
        }
    }
}
