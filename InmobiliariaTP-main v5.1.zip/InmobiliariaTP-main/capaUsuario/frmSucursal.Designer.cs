﻿
namespace capaUsuario
{
    partial class frmSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlAcceso = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lstTablaS = new System.Windows.Forms.ListBox();
            this.dtgViewTablaS = new System.Windows.Forms.DataGridView();
            this.gpr1 = new System.Windows.Forms.GroupBox();
            this.btnSucursalE = new System.Windows.Forms.Button();
            this.btnSucursalA = new System.Windows.Forms.Button();
            this.btnSucursalC = new System.Windows.Forms.Button();
            this.pnlAcceso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaS)).BeginInit();
            this.gpr1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAcceso
            // 
            this.pnlAcceso.BackColor = System.Drawing.Color.DarkGray;
            this.pnlAcceso.Controls.Add(this.btnSalir);
            this.pnlAcceso.Controls.Add(this.btnClose);
            this.pnlAcceso.Controls.Add(this.lstTablaS);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaS);
            this.pnlAcceso.Controls.Add(this.gpr1);
            this.pnlAcceso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAcceso.Location = new System.Drawing.Point(0, 0);
            this.pnlAcceso.Margin = new System.Windows.Forms.Padding(4);
            this.pnlAcceso.Name = "pnlAcceso";
            this.pnlAcceso.Size = new System.Drawing.Size(1402, 690);
            this.pnlAcceso.TabIndex = 1;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(1015, 614);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(162, 48);
            this.btnSalir.TabIndex = 42;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(25, 614);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(208, 48);
            this.btnClose.TabIndex = 41;
            this.btnClose.Text = "Almacenar";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lstTablaS
            // 
            this.lstTablaS.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaS.FormattingEnabled = true;
            this.lstTablaS.ItemHeight = 22;
            this.lstTablaS.Location = new System.Drawing.Point(679, 78);
            this.lstTablaS.Name = "lstTablaS";
            this.lstTablaS.Size = new System.Drawing.Size(268, 268);
            this.lstTablaS.TabIndex = 40;
            // 
            // dtgViewTablaS
            // 
            this.dtgViewTablaS.AllowUserToOrderColumns = true;
            this.dtgViewTablaS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaS.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaS.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaS.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgViewTablaS.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaS.Enabled = false;
            this.dtgViewTablaS.Location = new System.Drawing.Point(50, 78);
            this.dtgViewTablaS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaS.Name = "dtgViewTablaS";
            this.dtgViewTablaS.ReadOnly = true;
            this.dtgViewTablaS.RowHeadersWidth = 51;
            this.dtgViewTablaS.RowTemplate.Height = 28;
            this.dtgViewTablaS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaS.Size = new System.Drawing.Size(623, 270);
            this.dtgViewTablaS.TabIndex = 39;
            // 
            // gpr1
            // 
            this.gpr1.Controls.Add(this.btnSucursalE);
            this.gpr1.Controls.Add(this.btnSucursalA);
            this.gpr1.Controls.Add(this.btnSucursalC);
            this.gpr1.Location = new System.Drawing.Point(270, 399);
            this.gpr1.Margin = new System.Windows.Forms.Padding(4);
            this.gpr1.Name = "gpr1";
            this.gpr1.Padding = new System.Windows.Forms.Padding(4);
            this.gpr1.Size = new System.Drawing.Size(907, 189);
            this.gpr1.TabIndex = 2;
            this.gpr1.TabStop = false;
            // 
            // btnSucursalE
            // 
            this.btnSucursalE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnSucursalE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSucursalE.FlatAppearance.BorderSize = 0;
            this.btnSucursalE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnSucursalE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSucursalE.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSucursalE.ForeColor = System.Drawing.Color.White;
            this.btnSucursalE.Location = new System.Drawing.Point(543, 52);
            this.btnSucursalE.Margin = new System.Windows.Forms.Padding(4);
            this.btnSucursalE.Name = "btnSucursalE";
            this.btnSucursalE.Size = new System.Drawing.Size(186, 46);
            this.btnSucursalE.TabIndex = 44;
            this.btnSucursalE.Text = "Eliminar Sucursal";
            this.btnSucursalE.UseVisualStyleBackColor = false;
            this.btnSucursalE.Click += new System.EventHandler(this.btnSucursalE_Click);
            // 
            // btnSucursalA
            // 
            this.btnSucursalA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnSucursalA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSucursalA.FlatAppearance.BorderSize = 0;
            this.btnSucursalA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnSucursalA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSucursalA.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSucursalA.ForeColor = System.Drawing.Color.White;
            this.btnSucursalA.Location = new System.Drawing.Point(278, 52);
            this.btnSucursalA.Margin = new System.Windows.Forms.Padding(4);
            this.btnSucursalA.Name = "btnSucursalA";
            this.btnSucursalA.Size = new System.Drawing.Size(206, 46);
            this.btnSucursalA.TabIndex = 42;
            this.btnSucursalA.Text = "Actualizar Sucursal";
            this.btnSucursalA.UseVisualStyleBackColor = false;
            this.btnSucursalA.Click += new System.EventHandler(this.btnSucursalA_Click);
            // 
            // btnSucursalC
            // 
            this.btnSucursalC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnSucursalC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSucursalC.FlatAppearance.BorderSize = 0;
            this.btnSucursalC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnSucursalC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSucursalC.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSucursalC.ForeColor = System.Drawing.Color.White;
            this.btnSucursalC.Location = new System.Drawing.Point(21, 52);
            this.btnSucursalC.Margin = new System.Windows.Forms.Padding(4);
            this.btnSucursalC.Name = "btnSucursalC";
            this.btnSucursalC.Size = new System.Drawing.Size(206, 46);
            this.btnSucursalC.TabIndex = 37;
            this.btnSucursalC.Text = "Nueva Sucursal";
            this.btnSucursalC.UseVisualStyleBackColor = false;
            this.btnSucursalC.Click += new System.EventHandler(this.btnSucursalC_Click);
            // 
            // frmSucursal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1402, 690);
            this.Controls.Add(this.pnlAcceso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSucursal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FPrincipal_FormClosing);
            this.pnlAcceso.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaS)).EndInit();
            this.gpr1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAcceso;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ListBox lstTablaS;
        private System.Windows.Forms.DataGridView dtgViewTablaS;
        private System.Windows.Forms.GroupBox gpr1;
        private System.Windows.Forms.Button btnSucursalE;
        private System.Windows.Forms.Button btnSucursalA;
        private System.Windows.Forms.Button btnSucursalC;
        private System.Windows.Forms.Button btnSalir;
    }
}