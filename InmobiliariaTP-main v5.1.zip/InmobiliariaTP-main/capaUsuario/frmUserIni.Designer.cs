﻿
namespace capaUsuario
{
    partial class frmUserIni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlAcceso = new System.Windows.Forms.Panel();
            this.lstTablaV = new System.Windows.Forms.ListBox();
            this.dtgViewTablaV = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnEliminarV = new System.Windows.Forms.Button();
            this.btnActualizarV = new System.Windows.Forms.Button();
            this.btnVendedor = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lstTablaC = new System.Windows.Forms.ListBox();
            this.dtgViewTablaC = new System.Windows.Forms.DataGridView();
            this.gpr1 = new System.Windows.Forms.GroupBox();
            this.btnEliminarC = new System.Windows.Forms.Button();
            this.btnActualizarC = new System.Windows.Forms.Button();
            this.btnClienteC = new System.Windows.Forms.Button();
            this.pnlAcceso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaV)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaC)).BeginInit();
            this.gpr1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAcceso
            // 
            this.pnlAcceso.Controls.Add(this.lstTablaV);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaV);
            this.pnlAcceso.Controls.Add(this.groupBox1);
            this.pnlAcceso.Controls.Add(this.btnClose);
            this.pnlAcceso.Controls.Add(this.lstTablaC);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaC);
            this.pnlAcceso.Controls.Add(this.gpr1);
            this.pnlAcceso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAcceso.Location = new System.Drawing.Point(0, 0);
            this.pnlAcceso.Margin = new System.Windows.Forms.Padding(4);
            this.pnlAcceso.Name = "pnlAcceso";
            this.pnlAcceso.Size = new System.Drawing.Size(1420, 737);
            this.pnlAcceso.TabIndex = 0;
            // 
            // lstTablaV
            // 
            this.lstTablaV.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaV.FormattingEnabled = true;
            this.lstTablaV.ItemHeight = 22;
            this.lstTablaV.Location = new System.Drawing.Point(832, 388);
            this.lstTablaV.Name = "lstTablaV";
            this.lstTablaV.Size = new System.Drawing.Size(268, 268);
            this.lstTablaV.TabIndex = 44;
            // 
            // dtgViewTablaV
            // 
            this.dtgViewTablaV.AllowUserToOrderColumns = true;
            this.dtgViewTablaV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaV.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaV.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgViewTablaV.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaV.Enabled = false;
            this.dtgViewTablaV.Location = new System.Drawing.Point(42, 390);
            this.dtgViewTablaV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaV.Name = "dtgViewTablaV";
            this.dtgViewTablaV.ReadOnly = true;
            this.dtgViewTablaV.RowHeadersWidth = 51;
            this.dtgViewTablaV.RowTemplate.Height = 28;
            this.dtgViewTablaV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaV.Size = new System.Drawing.Size(784, 266);
            this.dtgViewTablaV.TabIndex = 43;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnEliminarV);
            this.groupBox1.Controls.Add(this.btnActualizarV);
            this.groupBox1.Controls.Add(this.btnVendedor);
            this.groupBox1.Location = new System.Drawing.Point(1112, 405);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(299, 189);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            // 
            // btnEliminarV
            // 
            this.btnEliminarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnEliminarV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminarV.FlatAppearance.BorderSize = 0;
            this.btnEliminarV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnEliminarV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminarV.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarV.ForeColor = System.Drawing.Color.White;
            this.btnEliminarV.Location = new System.Drawing.Point(105, 145);
            this.btnEliminarV.Margin = new System.Windows.Forms.Padding(4);
            this.btnEliminarV.Name = "btnEliminarV";
            this.btnEliminarV.Size = new System.Drawing.Size(186, 46);
            this.btnEliminarV.TabIndex = 44;
            this.btnEliminarV.Text = "Eliminar Vendedor";
            this.btnEliminarV.UseVisualStyleBackColor = false;
            this.btnEliminarV.Click += new System.EventHandler(this.btnEliminarV_Click);
            // 
            // btnActualizarV
            // 
            this.btnActualizarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnActualizarV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnActualizarV.FlatAppearance.BorderSize = 0;
            this.btnActualizarV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnActualizarV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActualizarV.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizarV.ForeColor = System.Drawing.Color.White;
            this.btnActualizarV.Location = new System.Drawing.Point(32, 81);
            this.btnActualizarV.Margin = new System.Windows.Forms.Padding(4);
            this.btnActualizarV.Name = "btnActualizarV";
            this.btnActualizarV.Size = new System.Drawing.Size(201, 46);
            this.btnActualizarV.TabIndex = 42;
            this.btnActualizarV.Text = "Actualizar Vendedor";
            this.btnActualizarV.UseVisualStyleBackColor = false;
            this.btnActualizarV.Click += new System.EventHandler(this.btnActualizarV_Click);
            // 
            // btnVendedor
            // 
            this.btnVendedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnVendedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVendedor.FlatAppearance.BorderSize = 0;
            this.btnVendedor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnVendedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVendedor.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVendedor.ForeColor = System.Drawing.Color.White;
            this.btnVendedor.Location = new System.Drawing.Point(32, 14);
            this.btnVendedor.Margin = new System.Windows.Forms.Padding(4);
            this.btnVendedor.Name = "btnVendedor";
            this.btnVendedor.Size = new System.Drawing.Size(201, 46);
            this.btnVendedor.TabIndex = 37;
            this.btnVendedor.Text = "Crear Vendedor";
            this.btnVendedor.UseVisualStyleBackColor = false;
            this.btnVendedor.Click += new System.EventHandler(this.btnVendedor_Click_1);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(22, 679);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(208, 48);
            this.btnClose.TabIndex = 41;
            this.btnClose.Text = "Salir";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lstTablaC
            // 
            this.lstTablaC.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaC.FormattingEnabled = true;
            this.lstTablaC.ItemHeight = 22;
            this.lstTablaC.Location = new System.Drawing.Point(832, 79);
            this.lstTablaC.Name = "lstTablaC";
            this.lstTablaC.Size = new System.Drawing.Size(268, 268);
            this.lstTablaC.TabIndex = 40;
            // 
            // dtgViewTablaC
            // 
            this.dtgViewTablaC.AllowUserToOrderColumns = true;
            this.dtgViewTablaC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaC.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaC.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgViewTablaC.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaC.Enabled = false;
            this.dtgViewTablaC.Location = new System.Drawing.Point(42, 79);
            this.dtgViewTablaC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaC.Name = "dtgViewTablaC";
            this.dtgViewTablaC.ReadOnly = true;
            this.dtgViewTablaC.RowHeadersWidth = 51;
            this.dtgViewTablaC.RowTemplate.Height = 28;
            this.dtgViewTablaC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaC.Size = new System.Drawing.Size(784, 270);
            this.dtgViewTablaC.TabIndex = 39;
            // 
            // gpr1
            // 
            this.gpr1.Controls.Add(this.btnEliminarC);
            this.gpr1.Controls.Add(this.btnActualizarC);
            this.gpr1.Controls.Add(this.btnClienteC);
            this.gpr1.Location = new System.Drawing.Point(1107, 92);
            this.gpr1.Margin = new System.Windows.Forms.Padding(4);
            this.gpr1.Name = "gpr1";
            this.gpr1.Padding = new System.Windows.Forms.Padding(4);
            this.gpr1.Size = new System.Drawing.Size(299, 189);
            this.gpr1.TabIndex = 2;
            this.gpr1.TabStop = false;
            // 
            // btnEliminarC
            // 
            this.btnEliminarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnEliminarC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminarC.FlatAppearance.BorderSize = 0;
            this.btnEliminarC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnEliminarC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminarC.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarC.ForeColor = System.Drawing.Color.White;
            this.btnEliminarC.Location = new System.Drawing.Point(105, 145);
            this.btnEliminarC.Margin = new System.Windows.Forms.Padding(4);
            this.btnEliminarC.Name = "btnEliminarC";
            this.btnEliminarC.Size = new System.Drawing.Size(186, 46);
            this.btnEliminarC.TabIndex = 44;
            this.btnEliminarC.Text = "Eliminar Cliente";
            this.btnEliminarC.UseVisualStyleBackColor = false;
            this.btnEliminarC.Click += new System.EventHandler(this.btnEliminarC_Click);
            // 
            // btnActualizarC
            // 
            this.btnActualizarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnActualizarC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnActualizarC.FlatAppearance.BorderSize = 0;
            this.btnActualizarC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnActualizarC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActualizarC.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizarC.ForeColor = System.Drawing.Color.White;
            this.btnActualizarC.Location = new System.Drawing.Point(32, 79);
            this.btnActualizarC.Margin = new System.Windows.Forms.Padding(4);
            this.btnActualizarC.Name = "btnActualizarC";
            this.btnActualizarC.Size = new System.Drawing.Size(206, 46);
            this.btnActualizarC.TabIndex = 42;
            this.btnActualizarC.Text = "Actualizar Cliente";
            this.btnActualizarC.UseVisualStyleBackColor = false;
            this.btnActualizarC.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // btnClienteC
            // 
            this.btnClienteC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnClienteC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClienteC.FlatAppearance.BorderSize = 0;
            this.btnClienteC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnClienteC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClienteC.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClienteC.ForeColor = System.Drawing.Color.White;
            this.btnClienteC.Location = new System.Drawing.Point(32, 14);
            this.btnClienteC.Margin = new System.Windows.Forms.Padding(4);
            this.btnClienteC.Name = "btnClienteC";
            this.btnClienteC.Size = new System.Drawing.Size(206, 46);
            this.btnClienteC.TabIndex = 37;
            this.btnClienteC.Text = "Crear Cliente";
            this.btnClienteC.UseVisualStyleBackColor = false;
            this.btnClienteC.Click += new System.EventHandler(this.btnCliente_Click);
            // 
            // frmUserIni
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1420, 737);
            this.Controls.Add(this.pnlAcceso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmUserIni";
            this.Text = "Inicio";
            this.pnlAcceso.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaV)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaC)).EndInit();
            this.gpr1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAcceso;
        private System.Windows.Forms.GroupBox gpr1;
        private System.Windows.Forms.Button btnClienteC;
        private System.Windows.Forms.DataGridView dtgViewTablaC;
        private System.Windows.Forms.ListBox lstTablaC;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnActualizarC;
        private System.Windows.Forms.Button btnEliminarC;
        private System.Windows.Forms.ListBox lstTablaV;
        private System.Windows.Forms.DataGridView dtgViewTablaV;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEliminarV;
        private System.Windows.Forms.Button btnActualizarV;
        private System.Windows.Forms.Button btnVendedor;
    }
}