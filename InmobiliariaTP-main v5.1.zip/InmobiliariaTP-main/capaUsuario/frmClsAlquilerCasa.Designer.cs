﻿
namespace capaUsuario
{
    partial class frmClsAlquilerCasa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lstTablaS = new System.Windows.Forms.ListBox();
            this.dtgViewTablaSuc = new System.Windows.Forms.DataGridView();
            this.lblSucursal = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblAlquilerValor = new System.Windows.Forms.Label();
            this.txtCostoTotal = new System.Windows.Forms.TextBox();
            this.lblVendedor = new System.Windows.Forms.Label();
            this.txtVendedor = new System.Windows.Forms.TextBox();
            this.lblCliente = new System.Windows.Forms.Label();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTituloCli = new System.Windows.Forms.Label();
            this.lstTablaV = new System.Windows.Forms.ListBox();
            this.dtgViewTablaVen = new System.Windows.Forms.DataGridView();
            this.lstTablaC = new System.Windows.Forms.ListBox();
            this.dtgViewTablaCli = new System.Windows.Forms.DataGridView();
            this.grpAcciones = new System.Windows.Forms.GroupBox();
            this.txtComisión = new System.Windows.Forms.TextBox();
            this.lblComisión = new System.Windows.Forms.Label();
            this.btnOperacion = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.grpCasa = new System.Windows.Forms.GroupBox();
            this.lblIdSucursal = new System.Windows.Forms.Label();
            this.txtSucursal = new System.Windows.Forms.TextBox();
            this.lblSeparador = new System.Windows.Forms.Label();
            this.lblDatosUbicacion = new System.Windows.Forms.Label();
            this.lblCostom2 = new System.Windows.Forms.Label();
            this.txtCostoSucLoc = new System.Windows.Forms.TextBox();
            this.txtIdCasa = new System.Windows.Forms.TextBox();
            this.lblIdCasa = new System.Windows.Forms.Label();
            this.textBoxM2Cubiertos = new System.Windows.Forms.TextBox();
            this.textBoxTotalM2 = new System.Windows.Forms.TextBox();
            this.textBoxProvincia = new System.Windows.Forms.TextBox();
            this.textBoxPartido = new System.Windows.Forms.TextBox();
            this.textBoxLocalidad = new System.Windows.Forms.TextBox();
            this.textBoxNumero = new System.Windows.Forms.TextBox();
            this.textBoxCalle = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAlquiler = new System.Windows.Forms.TextBox();
            this.lblAqlCasa = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaSuc)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaVen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaCli)).BeginInit();
            this.grpAcciones.SuspendLayout();
            this.grpCasa.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstTablaS
            // 
            this.lstTablaS.BackColor = System.Drawing.SystemColors.Control;
            this.lstTablaS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaS.FormattingEnabled = true;
            this.lstTablaS.ItemHeight = 20;
            this.lstTablaS.Location = new System.Drawing.Point(450, 47);
            this.lstTablaS.Name = "lstTablaS";
            this.lstTablaS.Size = new System.Drawing.Size(292, 64);
            this.lstTablaS.TabIndex = 77;
            // 
            // dtgViewTablaSuc
            // 
            this.dtgViewTablaSuc.AllowUserToOrderColumns = true;
            this.dtgViewTablaSuc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaSuc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaSuc.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgViewTablaSuc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaSuc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaSuc.DefaultCellStyle = dataGridViewCellStyle7;
            this.dtgViewTablaSuc.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaSuc.Enabled = false;
            this.dtgViewTablaSuc.Location = new System.Drawing.Point(748, 47);
            this.dtgViewTablaSuc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaSuc.Name = "dtgViewTablaSuc";
            this.dtgViewTablaSuc.ReadOnly = true;
            this.dtgViewTablaSuc.RowHeadersWidth = 51;
            this.dtgViewTablaSuc.RowTemplate.Height = 28;
            this.dtgViewTablaSuc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaSuc.Size = new System.Drawing.Size(786, 64);
            this.dtgViewTablaSuc.TabIndex = 76;
            // 
            // lblSucursal
            // 
            this.lblSucursal.AutoSize = true;
            this.lblSucursal.BackColor = System.Drawing.SystemColors.Control;
            this.lblSucursal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSucursal.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblSucursal.Location = new System.Drawing.Point(445, 19);
            this.lblSucursal.Name = "lblSucursal";
            this.lblSucursal.Size = new System.Drawing.Size(110, 25);
            this.lblSucursal.TabIndex = 75;
            this.lblSucursal.Text = "Sucursales";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblAlquilerValor);
            this.groupBox1.Controls.Add(this.txtCostoTotal);
            this.groupBox1.Controls.Add(this.lblVendedor);
            this.groupBox1.Controls.Add(this.txtVendedor);
            this.groupBox1.Controls.Add(this.lblCliente);
            this.groupBox1.Controls.Add(this.txtCliente);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(450, 627);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1084, 105);
            this.groupBox1.TabIndex = 74;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleccion";
            // 
            // lblAlquilerValor
            // 
            this.lblAlquilerValor.AutoSize = true;
            this.lblAlquilerValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlquilerValor.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblAlquilerValor.Location = new System.Drawing.Point(834, 30);
            this.lblAlquilerValor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAlquilerValor.Name = "lblAlquilerValor";
            this.lblAlquilerValor.Size = new System.Drawing.Size(170, 25);
            this.lblAlquilerValor.TabIndex = 77;
            this.lblAlquilerValor.Text = "Costo Total (u$s):";
            // 
            // txtCostoTotal
            // 
            this.txtCostoTotal.BackColor = System.Drawing.SystemColors.Control;
            this.txtCostoTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCostoTotal.Enabled = false;
            this.txtCostoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostoTotal.Location = new System.Drawing.Point(878, 59);
            this.txtCostoTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtCostoTotal.Name = "txtCostoTotal";
            this.txtCostoTotal.Size = new System.Drawing.Size(171, 27);
            this.txtCostoTotal.TabIndex = 76;
            // 
            // lblVendedor
            // 
            this.lblVendedor.AutoSize = true;
            this.lblVendedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendedor.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblVendedor.Location = new System.Drawing.Point(385, 43);
            this.lblVendedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVendedor.Name = "lblVendedor";
            this.lblVendedor.Size = new System.Drawing.Size(104, 25);
            this.lblVendedor.TabIndex = 75;
            this.lblVendedor.Text = "Vendedor:";
            // 
            // txtVendedor
            // 
            this.txtVendedor.Enabled = false;
            this.txtVendedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendedor.Location = new System.Drawing.Point(504, 43);
            this.txtVendedor.Margin = new System.Windows.Forms.Padding(4);
            this.txtVendedor.Name = "txtVendedor";
            this.txtVendedor.Size = new System.Drawing.Size(171, 34);
            this.txtVendedor.TabIndex = 74;
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliente.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCliente.Location = new System.Drawing.Point(61, 43);
            this.lblCliente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(79, 25);
            this.lblCliente.TabIndex = 73;
            this.lblCliente.Text = "Cliente:";
            // 
            // txtCliente
            // 
            this.txtCliente.Enabled = false;
            this.txtCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCliente.Location = new System.Drawing.Point(166, 43);
            this.txtCliente.Margin = new System.Windows.Forms.Padding(4);
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.Size = new System.Drawing.Size(171, 34);
            this.txtCliente.TabIndex = 72;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(445, 389);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 73;
            this.label1.Text = "Vendedores";
            // 
            // lblTituloCli
            // 
            this.lblTituloCli.AutoSize = true;
            this.lblTituloCli.BackColor = System.Drawing.SystemColors.Control;
            this.lblTituloCli.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloCli.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblTituloCli.Location = new System.Drawing.Point(445, 127);
            this.lblTituloCli.Name = "lblTituloCli";
            this.lblTituloCli.Size = new System.Drawing.Size(83, 25);
            this.lblTituloCli.TabIndex = 72;
            this.lblTituloCli.Text = "Clientes";
            // 
            // lstTablaV
            // 
            this.lstTablaV.BackColor = System.Drawing.SystemColors.Control;
            this.lstTablaV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaV.FormattingEnabled = true;
            this.lstTablaV.ItemHeight = 20;
            this.lstTablaV.Location = new System.Drawing.Point(450, 418);
            this.lstTablaV.Name = "lstTablaV";
            this.lstTablaV.Size = new System.Drawing.Size(292, 204);
            this.lstTablaV.TabIndex = 71;
            this.lstTablaV.Click += new System.EventHandler(this.lstTablaV_Click);
            // 
            // dtgViewTablaVen
            // 
            this.dtgViewTablaVen.AllowUserToOrderColumns = true;
            this.dtgViewTablaVen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaVen.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaVen.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgViewTablaVen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaVen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaVen.DefaultCellStyle = dataGridViewCellStyle8;
            this.dtgViewTablaVen.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaVen.Enabled = false;
            this.dtgViewTablaVen.Location = new System.Drawing.Point(748, 418);
            this.dtgViewTablaVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaVen.Name = "dtgViewTablaVen";
            this.dtgViewTablaVen.ReadOnly = true;
            this.dtgViewTablaVen.RowHeadersWidth = 51;
            this.dtgViewTablaVen.RowTemplate.Height = 28;
            this.dtgViewTablaVen.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaVen.Size = new System.Drawing.Size(786, 204);
            this.dtgViewTablaVen.TabIndex = 70;
            // 
            // lstTablaC
            // 
            this.lstTablaC.BackColor = System.Drawing.SystemColors.Control;
            this.lstTablaC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaC.FormattingEnabled = true;
            this.lstTablaC.ItemHeight = 20;
            this.lstTablaC.Location = new System.Drawing.Point(450, 155);
            this.lstTablaC.Name = "lstTablaC";
            this.lstTablaC.Size = new System.Drawing.Size(292, 224);
            this.lstTablaC.TabIndex = 69;
            this.lstTablaC.Click += new System.EventHandler(this.lstTablaC_Click);
            // 
            // dtgViewTablaCli
            // 
            this.dtgViewTablaCli.AllowUserToOrderColumns = true;
            this.dtgViewTablaCli.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaCli.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaCli.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgViewTablaCli.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaCli.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaCli.DefaultCellStyle = dataGridViewCellStyle9;
            this.dtgViewTablaCli.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaCli.Enabled = false;
            this.dtgViewTablaCli.Location = new System.Drawing.Point(748, 155);
            this.dtgViewTablaCli.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaCli.Name = "dtgViewTablaCli";
            this.dtgViewTablaCli.ReadOnly = true;
            this.dtgViewTablaCli.RowHeadersWidth = 51;
            this.dtgViewTablaCli.RowTemplate.Height = 28;
            this.dtgViewTablaCli.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaCli.Size = new System.Drawing.Size(786, 224);
            this.dtgViewTablaCli.TabIndex = 68;
            // 
            // grpAcciones
            // 
            this.grpAcciones.Controls.Add(this.txtAlquiler);
            this.grpAcciones.Controls.Add(this.lblAqlCasa);
            this.grpAcciones.Controls.Add(this.txtComisión);
            this.grpAcciones.Controls.Add(this.lblComisión);
            this.grpAcciones.Controls.Add(this.btnOperacion);
            this.grpAcciones.Controls.Add(this.btnSalir);
            this.grpAcciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAcciones.Location = new System.Drawing.Point(17, 738);
            this.grpAcciones.Name = "grpAcciones";
            this.grpAcciones.Size = new System.Drawing.Size(1517, 94);
            this.grpAcciones.TabIndex = 67;
            this.grpAcciones.TabStop = false;
            this.grpAcciones.Text = "Acciones";
            // 
            // txtComisión
            // 
            this.txtComisión.BackColor = System.Drawing.SystemColors.Control;
            this.txtComisión.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtComisión.Enabled = false;
            this.txtComisión.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComisión.Location = new System.Drawing.Point(755, 33);
            this.txtComisión.Margin = new System.Windows.Forms.Padding(4);
            this.txtComisión.Name = "txtComisión";
            this.txtComisión.Size = new System.Drawing.Size(171, 27);
            this.txtComisión.TabIndex = 77;
            // 
            // lblComisión
            // 
            this.lblComisión.AutoSize = true;
            this.lblComisión.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComisión.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblComisión.Location = new System.Drawing.Point(570, 33);
            this.lblComisión.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblComisión.Name = "lblComisión";
            this.lblComisión.Size = new System.Drawing.Size(170, 25);
            this.lblComisión.TabIndex = 75;
            this.lblComisión.Text = "Comisión Alquiler:";
            // 
            // btnOperacion
            // 
            this.btnOperacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOperacion.Location = new System.Drawing.Point(1166, 33);
            this.btnOperacion.Name = "btnOperacion";
            this.btnOperacion.Size = new System.Drawing.Size(122, 43);
            this.btnOperacion.TabIndex = 12;
            this.btnOperacion.Text = "Ingresar";
            this.btnOperacion.UseVisualStyleBackColor = true;
            this.btnOperacion.Click += new System.EventHandler(this.btnOperacion_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(1369, 33);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(122, 43);
            this.btnSalir.TabIndex = 13;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // grpCasa
            // 
            this.grpCasa.Controls.Add(this.lblIdSucursal);
            this.grpCasa.Controls.Add(this.txtSucursal);
            this.grpCasa.Controls.Add(this.lblSeparador);
            this.grpCasa.Controls.Add(this.lblDatosUbicacion);
            this.grpCasa.Controls.Add(this.lblCostom2);
            this.grpCasa.Controls.Add(this.txtCostoSucLoc);
            this.grpCasa.Controls.Add(this.txtIdCasa);
            this.grpCasa.Controls.Add(this.lblIdCasa);
            this.grpCasa.Controls.Add(this.textBoxM2Cubiertos);
            this.grpCasa.Controls.Add(this.textBoxTotalM2);
            this.grpCasa.Controls.Add(this.textBoxProvincia);
            this.grpCasa.Controls.Add(this.textBoxPartido);
            this.grpCasa.Controls.Add(this.textBoxLocalidad);
            this.grpCasa.Controls.Add(this.textBoxNumero);
            this.grpCasa.Controls.Add(this.textBoxCalle);
            this.grpCasa.Controls.Add(this.label10);
            this.grpCasa.Controls.Add(this.label9);
            this.grpCasa.Controls.Add(this.label8);
            this.grpCasa.Controls.Add(this.label5);
            this.grpCasa.Controls.Add(this.label4);
            this.grpCasa.Controls.Add(this.label3);
            this.grpCasa.Controls.Add(this.label2);
            this.grpCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCasa.Location = new System.Drawing.Point(17, 12);
            this.grpCasa.Name = "grpCasa";
            this.grpCasa.Size = new System.Drawing.Size(414, 720);
            this.grpCasa.TabIndex = 66;
            this.grpCasa.TabStop = false;
            this.grpCasa.Text = "Detalle de vivienda/casa";
            // 
            // lblIdSucursal
            // 
            this.lblIdSucursal.AutoSize = true;
            this.lblIdSucursal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdSucursal.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblIdSucursal.Location = new System.Drawing.Point(29, 634);
            this.lblIdSucursal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdSucursal.Name = "lblIdSucursal";
            this.lblIdSucursal.Size = new System.Drawing.Size(95, 25);
            this.lblIdSucursal.TabIndex = 75;
            this.lblIdSucursal.Text = "Sucursal:";
            // 
            // txtSucursal
            // 
            this.txtSucursal.Enabled = false;
            this.txtSucursal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSucursal.Location = new System.Drawing.Point(236, 634);
            this.txtSucursal.Margin = new System.Windows.Forms.Padding(4);
            this.txtSucursal.Name = "txtSucursal";
            this.txtSucursal.Size = new System.Drawing.Size(153, 34);
            this.txtSucursal.TabIndex = 74;
            // 
            // lblSeparador
            // 
            this.lblSeparador.AutoSize = true;
            this.lblSeparador.Location = new System.Drawing.Point(29, 499);
            this.lblSeparador.Name = "lblSeparador";
            this.lblSeparador.Size = new System.Drawing.Size(377, 29);
            this.lblSeparador.TabIndex = 73;
            this.lblSeparador.Text = "____________________________";
            // 
            // lblDatosUbicacion
            // 
            this.lblDatosUbicacion.AutoSize = true;
            this.lblDatosUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatosUbicacion.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblDatosUbicacion.Location = new System.Drawing.Point(29, 534);
            this.lblDatosUbicacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDatosUbicacion.Name = "lblDatosUbicacion";
            this.lblDatosUbicacion.Size = new System.Drawing.Size(0, 32);
            this.lblDatosUbicacion.TabIndex = 72;
            // 
            // lblCostom2
            // 
            this.lblCostom2.AllowDrop = true;
            this.lblCostom2.AutoSize = true;
            this.lblCostom2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostom2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCostom2.Location = new System.Drawing.Point(29, 580);
            this.lblCostom2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCostom2.Name = "lblCostom2";
            this.lblCostom2.Size = new System.Drawing.Size(153, 25);
            this.lblCostom2.TabIndex = 71;
            this.lblCostom2.Text = "Costo m2 (u$s):";
            // 
            // txtCostoSucLoc
            // 
            this.txtCostoSucLoc.Enabled = false;
            this.txtCostoSucLoc.Location = new System.Drawing.Point(236, 580);
            this.txtCostoSucLoc.Margin = new System.Windows.Forms.Padding(4);
            this.txtCostoSucLoc.Name = "txtCostoSucLoc";
            this.txtCostoSucLoc.Size = new System.Drawing.Size(153, 34);
            this.txtCostoSucLoc.TabIndex = 70;
            // 
            // txtIdCasa
            // 
            this.txtIdCasa.Enabled = false;
            this.txtIdCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdCasa.Location = new System.Drawing.Point(180, 463);
            this.txtIdCasa.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdCasa.Name = "txtIdCasa";
            this.txtIdCasa.Size = new System.Drawing.Size(112, 34);
            this.txtIdCasa.TabIndex = 69;
            // 
            // lblIdCasa
            // 
            this.lblIdCasa.AutoSize = true;
            this.lblIdCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdCasa.Location = new System.Drawing.Point(32, 463);
            this.lblIdCasa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdCasa.Name = "lblIdCasa";
            this.lblIdCasa.Size = new System.Drawing.Size(86, 25);
            this.lblIdCasa.TabIndex = 68;
            this.lblIdCasa.Text = "Id Casa:";
            // 
            // textBoxM2Cubiertos
            // 
            this.textBoxM2Cubiertos.Enabled = false;
            this.textBoxM2Cubiertos.Location = new System.Drawing.Point(180, 409);
            this.textBoxM2Cubiertos.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxM2Cubiertos.Name = "textBoxM2Cubiertos";
            this.textBoxM2Cubiertos.Size = new System.Drawing.Size(112, 34);
            this.textBoxM2Cubiertos.TabIndex = 67;
            // 
            // textBoxTotalM2
            // 
            this.textBoxTotalM2.Enabled = false;
            this.textBoxTotalM2.Location = new System.Drawing.Point(180, 353);
            this.textBoxTotalM2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTotalM2.Name = "textBoxTotalM2";
            this.textBoxTotalM2.Size = new System.Drawing.Size(112, 34);
            this.textBoxTotalM2.TabIndex = 66;
            // 
            // textBoxProvincia
            // 
            this.textBoxProvincia.Enabled = false;
            this.textBoxProvincia.Location = new System.Drawing.Point(180, 298);
            this.textBoxProvincia.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProvincia.Name = "textBoxProvincia";
            this.textBoxProvincia.Size = new System.Drawing.Size(209, 34);
            this.textBoxProvincia.TabIndex = 65;
            // 
            // textBoxPartido
            // 
            this.textBoxPartido.Enabled = false;
            this.textBoxPartido.Location = new System.Drawing.Point(180, 244);
            this.textBoxPartido.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPartido.Name = "textBoxPartido";
            this.textBoxPartido.Size = new System.Drawing.Size(209, 34);
            this.textBoxPartido.TabIndex = 64;
            // 
            // textBoxLocalidad
            // 
            this.textBoxLocalidad.Enabled = false;
            this.textBoxLocalidad.Location = new System.Drawing.Point(180, 188);
            this.textBoxLocalidad.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLocalidad.Name = "textBoxLocalidad";
            this.textBoxLocalidad.Size = new System.Drawing.Size(209, 34);
            this.textBoxLocalidad.TabIndex = 63;
            // 
            // textBoxNumero
            // 
            this.textBoxNumero.Enabled = false;
            this.textBoxNumero.Location = new System.Drawing.Point(180, 135);
            this.textBoxNumero.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNumero.Name = "textBoxNumero";
            this.textBoxNumero.Size = new System.Drawing.Size(209, 34);
            this.textBoxNumero.TabIndex = 62;
            // 
            // textBoxCalle
            // 
            this.textBoxCalle.Enabled = false;
            this.textBoxCalle.Location = new System.Drawing.Point(180, 83);
            this.textBoxCalle.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCalle.Name = "textBoxCalle";
            this.textBoxCalle.Size = new System.Drawing.Size(209, 34);
            this.textBoxCalle.TabIndex = 61;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(29, 409);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(129, 25);
            this.label10.TabIndex = 60;
            this.label10.Text = "M2 Cubiertos";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(29, 353);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 25);
            this.label9.TabIndex = 59;
            this.label9.Text = "Total M2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(26, 298);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 25);
            this.label8.TabIndex = 58;
            this.label8.Text = "Provincia";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 244);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 25);
            this.label5.TabIndex = 57;
            this.label5.Text = "Partido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 188);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 25);
            this.label4.TabIndex = 56;
            this.label4.Text = "Localidad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 135);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 25);
            this.label3.TabIndex = 55;
            this.label3.Text = "Numero";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 83);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 25);
            this.label2.TabIndex = 54;
            this.label2.Text = "Calle";
            // 
            // txtAlquiler
            // 
            this.txtAlquiler.BackColor = System.Drawing.SystemColors.Control;
            this.txtAlquiler.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAlquiler.Enabled = false;
            this.txtAlquiler.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlquiler.Location = new System.Drawing.Point(282, 31);
            this.txtAlquiler.Margin = new System.Windows.Forms.Padding(4);
            this.txtAlquiler.Name = "txtAlquiler";
            this.txtAlquiler.Size = new System.Drawing.Size(171, 27);
            this.txtAlquiler.TabIndex = 79;
            // 
            // lblAqlCasa
            // 
            this.lblAqlCasa.AutoSize = true;
            this.lblAqlCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAqlCasa.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblAqlCasa.Location = new System.Drawing.Point(120, 33);
            this.lblAqlCasa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAqlCasa.Name = "lblAqlCasa";
            this.lblAqlCasa.Size = new System.Drawing.Size(139, 25);
            this.lblAqlCasa.TabIndex = 78;
            this.lblAqlCasa.Text = "Alquiler (mes):";
            // 
            // frmClsAlquilerCasa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1551, 844);
            this.Controls.Add(this.lstTablaS);
            this.Controls.Add(this.dtgViewTablaSuc);
            this.Controls.Add(this.lblSucursal);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTituloCli);
            this.Controls.Add(this.lstTablaV);
            this.Controls.Add(this.dtgViewTablaVen);
            this.Controls.Add(this.lstTablaC);
            this.Controls.Add(this.dtgViewTablaCli);
            this.Controls.Add(this.grpAcciones);
            this.Controls.Add(this.grpCasa);
            this.Name = "frmClsAlquilerCasa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Operaciones de Alquiler";
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaSuc)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaVen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaCli)).EndInit();
            this.grpAcciones.ResumeLayout(false);
            this.grpAcciones.PerformLayout();
            this.grpCasa.ResumeLayout(false);
            this.grpCasa.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstTablaS;
        private System.Windows.Forms.DataGridView dtgViewTablaSuc;
        private System.Windows.Forms.Label lblSucursal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblAlquilerValor;
        private System.Windows.Forms.TextBox txtCostoTotal;
        private System.Windows.Forms.Label lblVendedor;
        private System.Windows.Forms.TextBox txtVendedor;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.TextBox txtCliente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTituloCli;
        private System.Windows.Forms.ListBox lstTablaV;
        private System.Windows.Forms.DataGridView dtgViewTablaVen;
        private System.Windows.Forms.ListBox lstTablaC;
        private System.Windows.Forms.DataGridView dtgViewTablaCli;
        private System.Windows.Forms.GroupBox grpAcciones;
        private System.Windows.Forms.TextBox txtComisión;
        private System.Windows.Forms.Label lblComisión;
        private System.Windows.Forms.Button btnOperacion;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.GroupBox grpCasa;
        private System.Windows.Forms.Label lblIdSucursal;
        private System.Windows.Forms.TextBox txtSucursal;
        private System.Windows.Forms.Label lblSeparador;
        private System.Windows.Forms.Label lblDatosUbicacion;
        private System.Windows.Forms.Label lblCostom2;
        private System.Windows.Forms.TextBox txtCostoSucLoc;
        private System.Windows.Forms.TextBox txtIdCasa;
        private System.Windows.Forms.Label lblIdCasa;
        private System.Windows.Forms.TextBox textBoxM2Cubiertos;
        private System.Windows.Forms.TextBox textBoxTotalM2;
        private System.Windows.Forms.TextBox textBoxProvincia;
        private System.Windows.Forms.TextBox textBoxPartido;
        private System.Windows.Forms.TextBox textBoxLocalidad;
        private System.Windows.Forms.TextBox textBoxNumero;
        private System.Windows.Forms.TextBox textBoxCalle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAlquiler;
        private System.Windows.Forms.Label lblAqlCasa;
    }
}