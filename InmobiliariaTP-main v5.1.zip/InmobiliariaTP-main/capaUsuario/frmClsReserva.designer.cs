﻿
namespace capaUsuario
{
    partial class frmClsReserva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstTablaReserva = new System.Windows.Forms.ListBox();
            this.listBoxCasas = new System.Windows.Forms.ListBox();
            this.listBoxDptos = new System.Windows.Forms.ListBox();
            this.listBoxClientes = new System.Windows.Forms.ListBox();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.butReservaDpto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstTablaReserva
            // 
            this.lstTablaReserva.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaReserva.FormattingEnabled = true;
            this.lstTablaReserva.ItemHeight = 17;
            this.lstTablaReserva.Location = new System.Drawing.Point(24, 34);
            this.lstTablaReserva.Margin = new System.Windows.Forms.Padding(2);
            this.lstTablaReserva.Name = "lstTablaReserva";
            this.lstTablaReserva.Size = new System.Drawing.Size(677, 106);
            this.lstTablaReserva.TabIndex = 41;
            // 
            // listBoxCasas
            // 
            this.listBoxCasas.BackColor = System.Drawing.Color.DarkGray;
            this.listBoxCasas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxCasas.FormattingEnabled = true;
            this.listBoxCasas.ItemHeight = 17;
            this.listBoxCasas.Location = new System.Drawing.Point(24, 171);
            this.listBoxCasas.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxCasas.Name = "listBoxCasas";
            this.listBoxCasas.Size = new System.Drawing.Size(677, 106);
            this.listBoxCasas.TabIndex = 42;
            // 
            // listBoxDptos
            // 
            this.listBoxDptos.BackColor = System.Drawing.Color.DarkGray;
            this.listBoxDptos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxDptos.FormattingEnabled = true;
            this.listBoxDptos.ItemHeight = 17;
            this.listBoxDptos.Location = new System.Drawing.Point(20, 313);
            this.listBoxDptos.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxDptos.Name = "listBoxDptos";
            this.listBoxDptos.Size = new System.Drawing.Size(681, 106);
            this.listBoxDptos.TabIndex = 43;
            // 
            // listBoxClientes
            // 
            this.listBoxClientes.BackColor = System.Drawing.Color.DarkGray;
            this.listBoxClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxClientes.FormattingEnabled = true;
            this.listBoxClientes.ItemHeight = 17;
            this.listBoxClientes.Location = new System.Drawing.Point(24, 444);
            this.listBoxClientes.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxClientes.Name = "listBoxClientes";
            this.listBoxClientes.Size = new System.Drawing.Size(677, 106);
            this.listBoxClientes.TabIndex = 44;
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnEliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminar.FlatAppearance.BorderSize = 0;
            this.btnEliminar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(712, 64);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(193, 37);
            this.btnEliminar.TabIndex = 45;
            this.btnEliminar.Text = "Eliminar Reserva";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(33, 7);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(225, 20);
            this.label.TabIndex = 46;
            this.label.Text = "RESERVAS REALIZADAS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "Casas Disponibles";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 20);
            this.label2.TabIndex = 48;
            this.label2.Text = "Dptos. Disponibles";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 421);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 49;
            this.label3.Text = "Clientes";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(712, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 37);
            this.button1.TabIndex = 50;
            this.button1.Text = "Reservar Casa";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // butReservaDpto
            // 
            this.butReservaDpto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.butReservaDpto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butReservaDpto.FlatAppearance.BorderSize = 0;
            this.butReservaDpto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.butReservaDpto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butReservaDpto.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butReservaDpto.ForeColor = System.Drawing.Color.White;
            this.butReservaDpto.Location = new System.Drawing.Point(712, 352);
            this.butReservaDpto.Name = "butReservaDpto";
            this.butReservaDpto.Size = new System.Drawing.Size(193, 37);
            this.butReservaDpto.TabIndex = 51;
            this.butReservaDpto.Text = "Reservar Dpto";
            this.butReservaDpto.UseVisualStyleBackColor = false;
            this.butReservaDpto.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmClsReserva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(959, 561);
            this.Controls.Add(this.butReservaDpto);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.listBoxClientes);
            this.Controls.Add(this.listBoxDptos);
            this.Controls.Add(this.listBoxCasas);
            this.Controls.Add(this.lstTablaReserva);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmClsReserva";
            this.Text = "frmClsReserva";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox lstTablaReserva;
        private System.Windows.Forms.ListBox listBoxCasas;
        private System.Windows.Forms.ListBox listBoxDptos;
        private System.Windows.Forms.ListBox listBoxClientes;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button butReservaDpto;
    }
}