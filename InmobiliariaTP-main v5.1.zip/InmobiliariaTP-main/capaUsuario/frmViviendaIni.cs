﻿using capaNegocio;
using System;
using System.Windows.Forms;

namespace capaUsuario
{
    public partial class frmViviendaIni : Form
    {
        private Inmobiliaria iCasa;
        private Inmobiliaria iDpto;
        private int cantcasa;
        private int cantdpto;

        public frmViviendaIni()
        {
            iCasa = Inmobiliaria.Recuperar("Casa.dat");
            iDpto = Inmobiliaria.Recuperar("Departamento.dat");
            
            InitializeComponent();
            //Cargar List y DataView.
            CargarCompView();            
            
        }
        //-----------------------Casa-------------------------
        private void btnCasa_Click(object sender, EventArgs e)
        {
            cantcasa = iCasa.CantCasa();
            Casa c = null;
            frmClsCasa agregar = new frmClsCasa(c, false, cantcasa);
            CargarInfo(agregar);
        }
        private void CargarInfo(frmClsCasa agregar)
        {
            agregar.ShowDialog();
            Casa cas = agregar.Cas;
            if (cas != null)
            {
                //Cargar el ListBox
                iCasa.agregarCasa(cas);
                GuardarInfo();

                //Cargar List y DataView.
                CargarCompView();
            }
        } 
        private void btnActualizarCasa_Click(object sender, EventArgs e)
        {            
            Casa c = (Casa)lstTablaCasa.SelectedItem;
            if (c != null)
            {
                frmClsCasa agregar = new frmClsCasa(c, true, 0);
                agregar.ShowDialog();
                GuardarInfo();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono una Casa.");
        }
        private void btnEliminarCasa_Click(object sender, EventArgs e)
        {
            Casa c = (Casa)lstTablaCasa.SelectedItem;
            if (c != null)
            {
                iCasa.eliminarCasa(c);
                GuardarInfo();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono una Casa.");
        }
        //-------------------Departamento-------------------------
        private void btnDpto_Click(object sender, EventArgs e)
        {
            cantdpto = iDpto.CantDpto();
            Dpto d = null;
            frmClsDpto agregar = new frmClsDpto(d, false, cantdpto);
            CargarInfoDpto(agregar);
        }
        private void CargarInfoDpto(frmClsDpto agregar)
        {
            agregar.ShowDialog();
            Dpto dep = agregar.DptoReturn;
            if (dep != null)
            {
                //Cargar el ListBox
                iDpto.agregarDpto(dep);
                GuardarInfo();

                //Cargar List y DataView.
                CargarCompView();
            }
        }
        private void butActDpto_Click(object sender, EventArgs e)
        {
            Dpto d = (Dpto)listBoxDpto.SelectedItem;
            if (d != null)
            {
                frmClsDpto agregar = new frmClsDpto(d, true, 0);
                agregar.ShowDialog();
                GuardarInfo();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono un Departamento.");
        }
        private void butEliminaDpto_Click(object sender, EventArgs e)
        {
            Dpto d = (Dpto)listBoxDpto.SelectedItem;
            if (d != null)
            {
                iDpto.eliminarDpto(d);
                GuardarInfo();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono un Departamento.");
        }
        private void CargarCompView()
        {
            //Cargar ListBox Casa
            lstTablaCasa.DataSource = null;
            lstTablaCasa.DataSource = iCasa.Casas;
            lstTablaCasa.ClearSelected();

            dtgViewTablaC.DataSource = null;
            dtgViewTablaC.DataSource = iCasa.Casas;
            dtgViewTablaC.ClearSelection();

            //Cargar ListBox Dpto
            listBoxDpto.DataSource = null;
            listBoxDpto.DataSource = iDpto.Dptos;
            listBoxDpto.ClearSelected();

            dtgViewTablaD.DataSource = null;
            dtgViewTablaD.DataSource = iDpto.Dptos;
            dtgViewTablaD.ClearSelection();
        }
        //-------------------Guardar datos-------------------------
        private void GuardarInfo()
        {
            if (iCasa.guardarCasa() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");

            if (iDpto.guardarDepartamento() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }

    }
}
