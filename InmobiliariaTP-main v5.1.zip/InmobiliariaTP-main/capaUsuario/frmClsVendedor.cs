﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsVendedor : capaUsuario.frmClsUsuario
    {
        Inmobiliaria iven = new Inmobiliaria("inmo");        
        private Vendedor ven;
        private int cant;

        public frmClsVendedor(Vendedor v, bool b, int cantven)
        {
            InitializeComponent();
            if (b)
            {
                btnIngresar.Enabled = true;
            }
            else
            {
                btnActualizar.Enabled = true;
                txtLegajo.Enabled = false;
            }
            if (v != null)
                CargarVendedor(v);
                ven = v;
            cant = cantven++ + 1000;
        }
        private void frmClsVendedor_Load(object sender, EventArgs e)
        {
            txtLegajo.Enabled = false;
            txtLegajo.Text = cant.ToString();
        }

        public Vendedor Ven
        {
            get { return ven; }
        }
        private void btnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                string nom = txtNombre.Text;
                string ape = txtApellido.Text;
                int dni = int.Parse(txtDni.Text);
                string ce = cmbCalle.Text;
                int al = int.Parse(txtAltura.Text);
                string loc = cmbLocalidad.Text;
                string par = cmbPartido.Text;
                int leg = int.Parse(txtLegajo.Text);
                ven = new Vendedor(nom, ape, dni, ce, al, loc, par, leg);

                //inmo.AgregarUsuario(usu);
                iven.AgregarVendedor(ven);

                CargarCompView();

                MessageBox.Show("Se ingreso correctamente el Cliente:" + leg);

                Limpiar();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            ven.Nombre = txtNombre.Text;
            ven.Apellido = txtApellido.Text;
            ven.Dni = int.Parse(txtDni.Text);
            ven.Calle = cmbCalle.Text;
            ven.Altura = int.Parse(txtAltura.Text);
            ven.Localidad = cmbLocalidad.Text;
            ven.Partido = cmbPartido.Text;
            ven.Legajo = int.Parse(txtLegajo.Text);

            this.Close();
        }
        private void CargarVendedor(Vendedor v)
        {
            try
            {
                txtNombre.Text = v.Nombre;
                txtApellido.Text = v.Apellido;
                txtDni.Text = v.Dni.ToString();
                cmbCalle.Text = v.Calle;
                txtAltura.Text = v.Altura.ToString();
                cmbLocalidad.Text = v.Localidad;
                cmbPartido.Text = v.Partido;
                txtLegajo.Text = v.Legajo.ToString();

                CargarCompView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            btnLimpiar.Enabled = false;
        }
        private void CargarCompView()
        {
            //Cargar DataGridView.
            dtgViewTabla.DataSource = null;
            dtgViewTabla.DataSource = iven.ListaVendedor;
            dtgViewTabla.ClearSelection();
        }
        private void Limpiar()
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDni.Text = "";
            cmbCalle.Text = "";
            txtAltura.Text = "0";
            cmbLocalidad.Text = "";
            cmbPartido.Text = "";

            this.txtLegajo.Text = "";
            this.txtNombre.Focus();
        }


    }
}
