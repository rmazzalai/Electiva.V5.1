﻿
namespace capaUsuario
{
    partial class frmComision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlAcceso = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.lstTablaC = new System.Windows.Forms.ListBox();
            this.dtgViewTablaC = new System.Windows.Forms.DataGridView();
            this.pnlAcceso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaC)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAcceso
            // 
            this.pnlAcceso.BackColor = System.Drawing.Color.DarkGray;
            this.pnlAcceso.Controls.Add(this.btnSalir);
            this.pnlAcceso.Controls.Add(this.lstTablaC);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaC);
            this.pnlAcceso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAcceso.Location = new System.Drawing.Point(0, 0);
            this.pnlAcceso.Margin = new System.Windows.Forms.Padding(4);
            this.pnlAcceso.Name = "pnlAcceso";
            this.pnlAcceso.Size = new System.Drawing.Size(1564, 690);
            this.pnlAcceso.TabIndex = 2;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(1371, 630);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(162, 48);
            this.btnSalir.TabIndex = 42;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // lstTablaC
            // 
            this.lstTablaC.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaC.FormattingEnabled = true;
            this.lstTablaC.ItemHeight = 22;
            this.lstTablaC.Location = new System.Drawing.Point(55, 62);
            this.lstTablaC.Name = "lstTablaC";
            this.lstTablaC.Size = new System.Drawing.Size(1488, 268);
            this.lstTablaC.TabIndex = 40;
            // 
            // dtgViewTablaC
            // 
            this.dtgViewTablaC.AllowUserToOrderColumns = true;
            this.dtgViewTablaC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaC.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaC.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgViewTablaC.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaC.Enabled = false;
            this.dtgViewTablaC.Location = new System.Drawing.Point(55, 357);
            this.dtgViewTablaC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaC.Name = "dtgViewTablaC";
            this.dtgViewTablaC.ReadOnly = true;
            this.dtgViewTablaC.RowHeadersWidth = 51;
            this.dtgViewTablaC.RowTemplate.Height = 28;
            this.dtgViewTablaC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaC.Size = new System.Drawing.Size(1488, 254);
            this.dtgViewTablaC.TabIndex = 39;
            // 
            // frmComision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1564, 690);
            this.Controls.Add(this.pnlAcceso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmComision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comisiones por Ventas/Alquileres";
            this.pnlAcceso.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAcceso;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.ListBox lstTablaC;
        private System.Windows.Forms.DataGridView dtgViewTablaC;
    }
}