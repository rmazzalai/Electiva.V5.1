﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsCliente : capaUsuario.frmClsUsuario
    {
        Inmobiliaria icli = new Inmobiliaria("inmo");        
        private Cliente cli;
        private int cant;

        public frmClsCliente(Cliente c,bool b, int cantcli)
        {
            
            InitializeComponent();
            //inmo.AgregarUsuario(c);
            if (b)
            {
                btnIngresar.Enabled = true;
            }else
            {
                btnActualizar.Enabled = true;
                txtNroCli.Enabled = false;
            }
            if(c != null)
                CargarUsuario(c);            
                cli = c;
            cant = cantcli++ + 100;
        }
        private void frmClsCliente_Load(object sender, EventArgs e)
        {
            txtNroCli.Enabled = false;
            txtNroCli.Text = "CLI-" + cant;
        }
        public Cliente Cli
        {
            get { return cli; }
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();           
        }
        private void dtgViewInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                btnIngresar.Enabled = false;                

                txtNombre.Text = dtgViewTabla.CurrentRow.Cells["Nombre"].Value.ToString();
                txtApellido.Text = dtgViewTabla.CurrentRow.Cells["Apellido"].Value.ToString();
                txtDni.Text = dtgViewTabla.CurrentRow.Cells["Dni"].Value.ToString();
                cmbCalle.Text = dtgViewTabla.CurrentRow.Cells["Calle"].Value.ToString();
                txtAltura.Text = dtgViewTabla.CurrentRow.Cells["Altura"].Value.ToString();
                cmbLocalidad.Text = dtgViewTabla.CurrentRow.Cells["Localidad"].Value.ToString();
                cmbPartido.Text = dtgViewTabla.CurrentRow.Cells["Partido"].Value.ToString();

                btnActualizar.Enabled = true;                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        //Ingresar un nuevo Cliente.
        private void btnIngresar_Click(object sender, EventArgs e)
        {            
            try
            {
                string nom = txtNombre.Text;
                string ape = txtApellido.Text;
                int dni = int.Parse(txtDni.Text);
                string ce = cmbCalle.Text;
                int al = int.Parse(txtAltura.Text);
                string loc = cmbLocalidad.Text;
                string par = cmbPartido.Text;
                //string cod = "CLI-" + txtNroCli.Text;
                string cod = txtNroCli.Text;
                cli = new Cliente(nom, ape, dni, ce, al, loc, par, cod);
                                
                icli.AgregarCliente(cli);

                CargarCompView();

                MessageBox.Show("Se ingreso correctamente el Cliente:" + cod);

                Limpiar();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }            
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            cli.Nombre = txtNombre.Text;
            cli.Apellido = txtApellido.Text;
            cli.Dni = int.Parse(txtDni.Text);
            cli.Calle = cmbCalle.Text;
            cli.Altura = int.Parse(txtAltura.Text);
            cli.Localidad = cmbLocalidad.Text;
            cli.Partido = cmbPartido.Text;
            cli.NroCli = txtNroCli.Text;

            this.Close();
        }
        private void Encabezado ()
        {
            try
            {
                //Crear columnas. Esto se elimina con datos almacenados en tablas.
                dtgViewTabla.Columns.Add("nombre", "Nombre");
                dtgViewTabla.Columns.Add("apellido", "Apellido");
                dtgViewTabla.Columns.Add("dni", "Dni");
                dtgViewTabla.Columns.Add("calle", "Calle");
                dtgViewTabla.Columns.Add("altura", "Altura");
                dtgViewTabla.Columns.Add("localidad", "Localidad");
                dtgViewTabla.Columns.Add("partido", "Partido");
                dtgViewTabla.Columns.Add("idcliente", "IdCliente");              

                btnIngresar.Enabled = true;

            }catch(Exception ex)
            { }
        }
        private void CargarUsuario(Cliente c)
        {
            try
            {
                txtNombre.Text = c.Nombre;
                txtApellido.Text = c.Apellido;
                txtDni.Text = c.Dni.ToString();
                cmbCalle.Text = c.Calle;
                txtAltura.Text = c.Altura.ToString();
                cmbLocalidad.Text = c.Localidad;
                cmbPartido.Text = c.Partido;
                txtNroCli.Text = c.NroCli;

                CargarCompView ();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            btnLimpiar.Enabled = false;
        }
        private void CargarCompView()
        {
            //Cargar DataGridView.
            dtgViewTabla.DataSource = null;
            dtgViewTabla.DataSource = icli.ListaClientes;
            dtgViewTabla.ClearSelection();
        }
        private void Limpiar()
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDni.Text = "";
            cmbCalle.Text = "";
            txtAltura.Text = "0";
            cmbLocalidad.Text = "";
            cmbPartido.Text = "";

            this.txtNroCli.Text = "";
            this.txtNombre.Focus();
        }

        private void cmbBusq_TextChanged(object sender, EventArgs e)
        {
            if (cmbBusq.Text != "")
            {
                txtBusq1.Enabled = true;
                txtBusq1.Focus();
            }
            else
            {
                txtBusq1.Text = "";
                txtBusq1.Enabled = false;
            }       
        }

        private void txtBusq1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string filterField = cmbBusq.Text;
                ((DataTable)dtgViewTabla.DataSource).DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", filterField, txtBusq1.Text);                
            }
            catch(Exception ex )
            {
                MessageBox.Show(ex.ToString());
            }
        }

    }
}
