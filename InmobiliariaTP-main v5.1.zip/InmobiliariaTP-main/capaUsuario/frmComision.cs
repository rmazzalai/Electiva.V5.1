﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmComision : Form
    {
        private Inmobiliaria icom
            ;

        public frmComision()
        {
            icom = Inmobiliaria.Recuperar("Comision.dat");
            InitializeComponent();

            CargarCompViewc();
        }
        private void CargarCompViewc()
        {
            //Cargar ListBox.
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = icom.ListaComisiones;
            lstTablaC.ClearSelected();

            //Cargar DataGridView.
            dtgViewTablaC.DataSource = null;
            dtgViewTablaC.DataSource = icom.ListaComisiones;
            dtgViewTablaC.ClearSelection();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
