﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmclsVenta : Form
    {
        private Inmobiliaria icasa;
        private Inmobiliaria idpto;

        public frmclsVenta()
        {
            icasa = Inmobiliaria.Recuperar("Casa.dat");
            idpto = Inmobiliaria.Recuperar("Departamento.dat");

            InitializeComponent();
            //Cargar List y DataView.
            CargarCompViewC();
            CargarCompViewD();
        }
    }
    private void CargarCompViewC()
    {
        //Cargar ListBox.
        lstTablaC.DataSource = null;
        lstTablaC.DataSource = icasa.L;
        lstTablaC.ClearSelected();

        //Cargar DataGridView.
        dtgViewTablaC.DataSource = null;
        dtgViewTablaC.DataSource = icli.ListaClientes;
        dtgViewTablaC.ClearSelection();
    }
    private void CargarCompViewD()
    {
        //Cargar ListBox.
        lstTablaD.DataSource = null;
        lstTablaD.DataSource = iven.ListaVendedor;
        lstTablaD.ClearSelected();

        //Cargar DataGridView.
        dtgViewTablaV.DataSource = null;
        dtgViewTablaV.DataSource = iven.ListaVendedor;
        dtgViewTablaV.ClearSelection();
    }
}
