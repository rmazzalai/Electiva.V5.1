﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmVenta : Form
    {
        private Inmobiliaria icasa;
        private Inmobiliaria idpto;
        private Inmobiliaria iven;
        private Inmobiliaria ires;
        private Inmobiliaria icom;

        public frmVenta()
        {
            icasa = Inmobiliaria.Recuperar("Casa.dat");
            idpto = Inmobiliaria.Recuperar("Departamento.dat");
            iven = Inmobiliaria.Recuperar("Venta.dat");
            ires = Inmobiliaria.Recuperar("Reserva.dat");
            icom = Inmobiliaria.Recuperar("Comision.dat");

            InitializeComponent();
            //Cargar List y DataView.
            CargarCompViewC();
            CargarCompViewD();
            CargarCompViewO();            
        }
        //-----------------------Casa------------------------
        private void btnVentaCasa_Click(object sender, EventArgs e)
        {
            Casa c = (Casa)lstTablaC.SelectedItem;
            Reserva r = (Reserva)lstTablaR.SelectedItem;
            if (c != null)
            {
                frmClsVentaCasa agregar = new frmClsVentaCasa(c, r);
                CargarInfoC(agregar, c);

                icom = Inmobiliaria.Recuperar("Comision.dat");
            }
            else
                MessageBox.Show("No selecciono una Vivienda/Casa");
        }
        private void CargarInfoC(frmClsVentaCasa agregar, Casa c)
        {
            agregar.ShowDialog();
            lstTablaR.ClearSelected();

            Venta v = agregar.Venta;
            if (v != null)
            {
                //Carga la venta.
                iven.AgregarUnaVenta(v);

                //Cambia el estado de la Casa.
                c.Estado = "V";
                //Guarda nuevos valores(estados), en Casa.
                icasa.guardarCasa();

                //Carga la casa vendida.
                iven.guardarVenta();

                //Cargar List y DataView.
                CargarCompViewO();
                CargarCompViewC();
            }
        }
        //-----------------------Departamento------------------------
        private void btnVenderDpto_Click(object sender, EventArgs e)
        {
            Dpto d = (Dpto)lstTablaD.SelectedItem;
            Reserva r = (Reserva)lstTablaR.SelectedItem;
            if (d != null)
            {
                frmClsVentaDpto agregar = new frmClsVentaDpto(d, r);
                CargarInfoC(agregar, d);
                
                icom = Inmobiliaria.Recuperar("Comision.dat");
            }
            else
                MessageBox.Show("No selecciono una Vivienda/Departamento");
        }
        private void CargarInfoC(frmClsVentaDpto agregar, Dpto d)
        {
            agregar.ShowDialog();
            lstTablaR.ClearSelected();

            Venta v = agregar.Venta;
            if (v != null)
            {
                //Carga la venta.
                iven.AgregarUnaVenta(v);

                //Cambia el estado de la Casa.
                d.Estado = "V";
                //Guarda nuevos valores(estados), en Casa.
                idpto.guardarDepartamento();

                //Carga la casa vendida.
                iven.guardarVenta();

                //Cargar List y DataView.
                CargarCompViewO();
                CargarCompViewD();
            }
        }
        //-----------------------Departamento o Casa----------------
        private void btnEliminarOper_Click(object sender, EventArgs e)
        {
            Venta v = (Venta)lstTablaO.SelectedItem;
            Comision m = (Comision)lstTablaOper.SelectedItem;
            if (v != null)
            {
                if (v.IdInmueble.Substring(0, 2) == "CA")
                { //Es una Casa.                    
                    for (var i = 0; i < icasa.CantCasa(); i++)
                    {
                        Casa c = icasa.Casas[i];
                        if (v.IdInmueble == c.Id)
                        {
                            c.Estado = null;
                            //Guarda Info en tabla.
                            GuardarICasa();
                        }
                    }
                }
                else //Es un dpto.
                {
                    //Inmobiliaria idptovendaux = new Inmobiliaria("inmo");
                    for (var i = 0; i < idpto.CantDpto(); i++)
                    {
                        Dpto d = idpto.Dptos[i];
                        if (v.IdInmueble == d.Id)
                        {
                            d.Estado = null;
                            //Guarda Info en tabla.
                            GuardarIDpto();
                        }
                    }
                }

                //Elimina Comisión.        Verificar esto que elimina
                                            //datos en Tabla Comision.
                icom.EliminarComision(m);
                GuardarIComision();

                //Eliminar venta.
                iven.EliminarUnaVenta(v);
                GuardarIVenta();


                //Carga List y DataGrid.
                CargarCompViewC();
                CargarCompViewD();
                CargarCompViewO();
            }
            else
                MessageBox.Show("No selecciono una Venta para eliminar");
        }
        private void CargarCompViewD()
        {
            Inmobiliaria dptoaux = new Inmobiliaria("inmo");
            for (var i = 0; i < idpto.Dptos.Count; i++)
            {
                Dpto d = idpto.Dptos[i];
                if (d.Estado != "V" || d.Estado == "A")
                {
                    dptoaux.agregarDpto(d);
                }
            }
            //Cargar ListBox.
            lstTablaD.DataSource = null;
            lstTablaD.DataSource = dptoaux.Dptos;
            lstTablaD.ClearSelected();
        }        
        private void CargarCompViewC()
        {
            Inmobiliaria casaaux = new Inmobiliaria("inmo");
            for (var i = 0; i < icasa.Casas.Count; i++)
            {
                Casa c = icasa.Casas[i];
                if (c.Estado != "V" || c.Estado == "A")
                {
                    casaaux.agregarCasa(c);
                }
            }
            //Cargar ListBox Casa
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = casaaux.Casas;
            lstTablaC.ClearSelected();
        }
        //Asocia y muestra si tiene una reserva para la Casa.
        private void lstTablaC_Click(object sender, EventArgs e)
        {
            lstTablaD.ClearSelected();
            lstTablaR.DataSource = null;
            Casa c = (Casa)lstTablaC.SelectedItem;
            Inmobiliaria reservaaux = new Inmobiliaria("inmo");
            for (var i = 0; i < ires.Reserva.Count; i++)
            {
                Reserva r = ires.Reserva[i];
                if (c != null && r.DptoReserva == null)
                {                     
                    if (r.CasaReserva.Id == c.Id)
                    {
                        reservaaux.AgregarReserva(r);
                        c = null;
                    }
                }
            }
            //Cargar dataGridView.
            lstTablaR.DataSource = null;
            lstTablaR.DataSource = reservaaux.Reserva;
            lstTablaR.Select();

        }
        //Asocia y muestra si tiene una reserva para el un Dpto.
        private void lstTablaD_Click(object sender, EventArgs e)
        {
            lstTablaC.ClearSelected();
            lstTablaR.DataSource = null;
            Dpto d = (Dpto)lstTablaD.SelectedItem;
            Inmobiliaria reservaaux = new Inmobiliaria("inmo");
            for (var i = 0; i < ires.Reserva.Count; i++)
            {
                Reserva r = ires.Reserva[i];
                if (d != null && r.CasaReserva == null)
                {                    
                    if (r.DptoReserva.Id == d.Id)
                    {
                        reservaaux.AgregarReserva(r);
                        d = null;
                    }
                }
            }
            //Cargar dataGridView.
            lstTablaR.DataSource = null;
            lstTablaR.DataSource = reservaaux.Reserva;
            lstTablaR.Select();
        }
        //Asocia y muestra si tiene una comision con esa venta.  
        private void lstTablaO_Click(object sender, EventArgs e)
        {
            //Trae la comisión por tipo de Vivienda.
            Venta v = (Venta)lstTablaO.SelectedItem;
            Inmobiliaria auxiliar = new Inmobiliaria("inmo");
              
            for (var i = 0; i < icom.CantComision(); i++)
            {
                Comision c = icom.ListaComisiones[i];
                if (v != null && icom != null)
                {
                    if (v.IdInmueble.Substring(0, 2) == "CA")
                    {// Es una Casa.
                        if (v != null && c.IDDpto == null)
                        {
                            if (v.IdInmueble == c.IDCasa.Id)
                            {
                                auxiliar.AgregarComision(c);
                                v = null;
                            }
                        }
                    }
                    else
                    {// Es ub Dpto.
                        if (v != null && c.IDCasa == null)
                        {
                            if (v.IdInmueble == c.IDDpto.Id)
                            {
                                auxiliar.AgregarComision(c);
                                v = null;
                            }
                        }
                    }
                }
            }
            //Cargar dataGridView.
            lstTablaOper.DataSource = null;
            lstTablaOper.DataSource = auxiliar.ListaComisiones;
            lstTablaOper.Select();
        }
        private void CargarCompViewO()
        {
            //Cargar ListBox.
            lstTablaO.DataSource = null;
            lstTablaO.DataSource = iven.ListaVentas;
            lstTablaO.ClearSelected();

            //Cargar dataGridView.
            dtgViewTablaO.DataSource = null;
            dtgViewTablaO.DataSource = iven.ListaVentas;
            dtgViewTablaO.ClearSelection();
        }
        private void CargarCompView()
        {
            //Cargar ListBox.
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = icasa.Casas;
            lstTablaC.ClearSelected();
        }
        private void GuardarICasa()
        {
            if (icasa.guardarCasa() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarIDpto()
        {
            if (idpto.guardarDepartamento() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarIVenta()
        {
            if (iven.guardarVenta() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarIComision()
        {
            if (iven.guardarComision() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void butSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
